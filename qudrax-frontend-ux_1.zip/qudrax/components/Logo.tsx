export default function Logo({ size = 28 }: { size?: number }) {
  return (<span className="inline-flex items-center gap-2.5">
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden><defs><linearGradient id="qx-logo" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#00D9FF" /><stop offset="1" stopColor="#8B5CF6" /></linearGradient></defs>
      <circle cx="15" cy="15" r="10" fill="none" stroke="url(#qx-logo)" strokeWidth="3.5" /><path d="M19.5 19.5l7.5 7.5" stroke="url(#qx-logo)" strokeWidth="3.5" strokeLinecap="round" /></svg>
    <span className="font-display text-lg font-semibold tracking-tight">QudraX</span></span>);
}
