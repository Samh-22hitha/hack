import type { AvatarState } from "@/lib/store";
const meta: Record<AvatarState, { label: string; c: string }> = {
  idle: { label: "Your turn when you are ready", c: "#00D9FF" }, speaking: { label: "Interviewer is speaking", c: "#00D9FF" },
  listening: { label: "Listening to you", c: "#10B981" }, thinking: { label: "Scoring your answer", c: "#8B5CF6" } };
// Shows what the interviewer is doing right now. Colour matches the avatar's glow.
export default function StatusPill({ state, live = true }: { state: AvatarState; live?: boolean }) {
  const m = meta[state];
  return (<p role={live ? "status" : undefined} className="glass inline-flex items-center gap-2.5 px-4 py-1.5 text-sm">
    <span className="relative flex size-2.5"><span className="absolute inset-0 animate-ping rounded-full opacity-60" style={{ background: m.c }} /><span className="relative size-2.5 rounded-full" style={{ background: m.c }} /></span>
    {m.label}
    {state === "thinking" && <span aria-hidden className="flex gap-1">{[0, 1, 2].map((d) => <span key={d} className="size-1 animate-bounce rounded-full bg-ink/70" style={{ animationDelay: `${d * 120}ms` }} />)}</span>}
  </p>);
}
