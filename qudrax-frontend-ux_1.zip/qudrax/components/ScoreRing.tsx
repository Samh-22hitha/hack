"use client";
import { useId } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { useCountUp } from "@/lib/useCountUp";
export default function ScoreRing({ value, size = 128, stroke = 10, label, from = "#00D9FF", to = "#8B5CF6" }:
  { value: number; size?: number; stroke?: number; label?: string; from?: string; to?: string }) {
  const id = useId().replace(/:/g, ""); const reduce = useReducedMotion(); const n = useCountUp(value);
  const r = (size - stroke) / 2, c = size / 2, p = Math.max(0, Math.min(1, value / 100));
  return (<div className="relative shrink-0" style={{ width: size, height: size }} role="img" aria-label={`${label ?? "Score"}: ${value} out of 100`}>
    <svg width={size} height={size} className="-rotate-90"><defs><linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={from} /><stop offset="1" stopColor={to} /></linearGradient></defs>
      <circle cx={c} cy={c} r={r} fill="none" stroke="#ffffff14" strokeWidth={stroke} />
      <motion.circle cx={c} cy={c} r={r} fill="none" stroke={`url(#${id})`} strokeWidth={stroke} strokeLinecap="round" initial={{ pathLength: reduce ? p : 0 }} animate={{ pathLength: p }} transition={{ duration: reduce ? 0 : 1.1, ease: "easeOut" }} /></svg>
    <div className="absolute inset-0 grid place-items-center text-center"><div><p className="font-num font-semibold leading-none" style={{ fontSize: size * 0.3 }}>{n}</p>{label && <p className="mt-1 text-xs text-ink/60">{label}</p>}</div></div>
  </div>);
}
