"use client";
import { Canvas, useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import type { AvatarState } from "@/lib/store";
// Procedural stand-in for a humanoid. To use a real GLB: drop it in /public, load it with a GLTF loader, and drive the same `state` values below.
const COLORS: Record<AvatarState, string> = { idle: "#00D9FF", speaking: "#00D9FF", listening: "#10B981", thinking: "#8B5CF6" };
function Figure({ state }: { state: AvatarState }) {
  const body = useRef<THREE.Group>(null!), head = useRef<THREE.Group>(null!), mouth = useRef<THREE.Mesh>(null!), eyes = useRef<THREE.Group>(null!), ring = useRef<THREE.Mesh>(null!);
  const glow = COLORS[state];
  useFrame(({ clock }, dt) => { const t = clock.elapsedTime, d = THREE.MathUtils.damp;
    body.current.position.y = -0.1 + Math.sin(t * 1.2) * 0.03;
    // Speaking and listening: look straight at the candidate. Thinking: glance aside and up. Idle: a slow, relaxed sway.
    const ty = state === "thinking" ? 0.4 : state === "idle" ? Math.sin(t * 0.5) * 0.12 : 0;
    const tx = state === "thinking" ? -0.14 : state === "listening" ? 0.04 + Math.sin(t * 2.2) * 0.03 : state === "speaking" ? -0.02 : 0;
    head.current.rotation.y = d(head.current.rotation.y, ty, 4, dt); head.current.rotation.x = d(head.current.rotation.x, tx, 4, dt);
    body.current.rotation.y = d(body.current.rotation.y, ty * 0.3, 2, dt);
    mouth.current.scale.y = d(mouth.current.scale.y, state === "speaking" ? 0.4 + Math.abs(Math.sin(t * 9) * Math.sin(t * 5.3)) * 1.5 : 0.3, 18, dt);
    eyes.current.scale.y = d(eyes.current.scale.y, t % 4.2 > 4.08 ? 0.1 : 1, 40, dt);
    ring.current.scale.setScalar(state === "listening" ? 1 + Math.sin(t * 4) * 0.06 : 1); });
  const glowMat = <meshStandardMaterial color={glow} emissive={glow} emissiveIntensity={2.5} />;
  return (<group ref={body} position={[0, -0.1, 0]}>
    <mesh position={[0, -0.55, 0]}><capsuleGeometry args={[0.46, 0.7, 8, 24]} /><meshStandardMaterial color="#182238" roughness={0.55} metalness={0.3} /></mesh>
    <mesh position={[0, -0.02, 0]} rotation={[0, 0, Math.PI / 2]}><capsuleGeometry args={[0.2, 0.95, 8, 24]} /><meshStandardMaterial color="#1d2a47" roughness={0.5} metalness={0.3} /></mesh>
    <mesh position={[0, -0.35, 0.47]}><sphereGeometry args={[0.05, 16, 16]} />{glowMat}</mesh>
    <mesh position={[0, 0.2, 0]}><cylinderGeometry args={[0.11, 0.14, 0.3, 24]} /><meshStandardMaterial color="#2a3858" roughness={0.6} /></mesh>
    <group ref={head} position={[0, 0.82, 0]}>
      <mesh><sphereGeometry args={[0.5, 48, 48]} /><meshStandardMaterial color="#d7deee" roughness={0.35} metalness={0.15} /></mesh>
      <mesh position={[0, 0.03, 0.3]} scale={[0.86, 0.5, 0.5]}><sphereGeometry args={[0.5, 40, 40]} /><meshStandardMaterial color="#0a1020" roughness={0.15} metalness={0.6} /></mesh>
      <group ref={eyes} position={[0, 0.08, 0.53]}>{[-0.17, 0.17].map((x) => <mesh key={x} position={[x, 0, 0]}><sphereGeometry args={[0.05, 20, 20]} />{glowMat}</mesh>)}</group>
      <mesh ref={mouth} position={[0, -0.29, 0.42]}><boxGeometry args={[0.22, 0.06, 0.04]} /><meshStandardMaterial color="#10182B" /></mesh>
      {[-1, 1].map((s) => <group key={s} position={[s * 0.5, 0, 0]}>
        <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.14, 0.14, 0.08, 32]} /><meshStandardMaterial color="#182238" roughness={0.5} metalness={0.3} /></mesh>
        <mesh position={[s * 0.05, 0, 0]} rotation={[0, Math.PI / 2, 0]}><torusGeometry args={[0.1, 0.012, 8, 32]} /><meshBasicMaterial color={glow} /></mesh></group>)}
    </group>
    <mesh ref={ring} position={[0, -1.4, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[1.05, 0.015, 8, 96]} /><meshBasicMaterial color={glow} /></mesh>
    <mesh position={[0, -1.4, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[1.4, 0.01, 8, 96]} /><meshBasicMaterial color={glow} transparent opacity={0.3} /></mesh>
  </group>);
}
export default function Avatar({ state }: { state: AvatarState }) {
  return (<Canvas dpr={[1, 2]} camera={{ position: [0, 0.2, 4.3], fov: 40 }} aria-label={`Interviewer is ${state}`}>
    <ambientLight intensity={0.7} /><pointLight position={[2, 3, 3]} intensity={30} color="#00D9FF" /><pointLight position={[-3, 1, 2]} intensity={20} color="#8B5CF6" />
    <Figure state={state} /></Canvas>);
}
