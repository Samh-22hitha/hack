"use client";
import { useMemo, useState } from "react";
const RINGS = [{ d: 40, speed: 70, rev: false, color: "#00D9FF" }, { d: 68, speed: 95, rev: true, color: "#8B5CF6" }, { d: 94, speed: 130, rev: false, color: "#94a3b8" }];
const MAX = 15;
// Skills orbit "you". The orbit pauses on hover or keyboard focus so every label is easy to read and click.
export default function SkillGalaxy({ skills, idle }: { skills: string[]; idle?: string }) {
  const [active, setActive] = useState<string | null>(null);
  const groups = useMemo(() => { const g: string[][] = [[], [], []]; skills.slice(0, MAX).forEach((s, i) => g[i % 3].push(s)); return g; }, [skills]);
  return (<div className="galaxy">
    <div className="relative mx-auto aspect-square w-full max-w-[440px]">
      {RINGS.map((r, k) => (<div key={k} className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border" style={{ width: `${r.d}%`, height: `${r.d}%`, borderColor: r.color + "33" }}>
        <div className={`absolute inset-0 ${r.rev ? "orbit-rev" : "orbit"}`} style={{ "--d": `${r.speed}s` } as React.CSSProperties}>
          {groups[k].map((s, i) => { const a = (i / groups[k].length) * Math.PI * 2 + k * 0.9;
            return (<div key={s} className="absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${50 + 50 * Math.cos(a)}%`, top: `${50 + 50 * Math.sin(a)}%` }}>
              <div className={r.rev ? "orbit" : "orbit-rev"} style={{ "--d": `${r.speed}s` } as React.CSSProperties}>
                <button type="button" onMouseEnter={() => setActive(s)} onFocus={() => setActive(s)} onClick={() => setActive(s)} onMouseLeave={() => setActive(null)} onBlur={() => setActive(null)}
                  className={`whitespace-nowrap rounded-full border px-3 py-1 text-xs transition sm:text-sm ${active === s ? "border-cyan bg-cyan text-navy shadow-[0_0_20px_#00D9FF88]" : "bg-navy/80 text-ink hover:border-cyan"}`} style={active === s ? undefined : { borderColor: r.color + "88" }}>{s}</button>
              </div></div>); })}
        </div></div>))}
      <div className="absolute left-1/2 top-1/2 grid size-[20%] -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-gradient-to-br from-cyan to-violet font-display text-sm font-semibold text-navy shadow-[0_0_40px_#00D9FF66] sm:text-base">You</div>
    </div>
    <p aria-live="polite" className="mt-3 min-h-5 text-center text-sm text-ink/60">
      {active ? `${active} was found in your resume.` : skills.length ? "Hover or tab to a skill to pause the orbit." : idle}
      {skills.length > MAX && !active ? ` Showing ${MAX} of ${skills.length} skills.` : ""}</p>
  </div>);
}
