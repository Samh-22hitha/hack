"use client";
import Link from "next/link"; import { usePathname } from "next/navigation"; import { useEffect, useState } from "react";
import { LayoutDashboard, FileUp, Mic, BarChart3, GitCompare, Check } from "lucide-react";
import { MotionConfig, motion } from "framer-motion"; import { Toaster } from "sonner";
import Logo from "@/components/Logo"; import { useStore } from "@/lib/store"; import { useJourney } from "@/lib/journey";
const nav = [["/dashboard", "Dashboard", LayoutDashboard], ["/resume", "Resume", FileUp], ["/interview", "Interview", Mic], ["/report", "Report", BarChart3], ["/mirror", "The Mirror", GitCompare]] as const;
export default function Shell({ children }: { children: React.ReactNode }) {
  const p = usePathname(); const [ready, setReady] = useState(false); const j = useJourney();
  // Load the saved session after mount so the first render matches the server.
  useEffect(() => { useStore.persist.rehydrate(); setReady(true); }, []);
  const done: Record<string, boolean> = { "/resume": j.analysed, "/interview": j.a1, "/mirror": j.a2 };
  const toaster = <Toaster theme="dark" position="top-center" closeButton toastOptions={{ style: { background: "#10182B", border: "1px solid #ffffff1f", color: "#F8FAFC" } }} />;
  let body: React.ReactNode;
  if (p === "/") body = children;                       // landing page: full-bleed, renders on the server
  else if (!ready) body = <div className="min-h-dvh" />; // wait for the saved session so pages never flash an empty state
  else if (p === "/interview") body = children;          // interview room: full-bleed, no chrome
  else body = (<div className="flex min-h-dvh">
    <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-cyan focus:px-3 focus:py-2 focus:text-navy">Skip to content</a>
    <nav aria-label="Main" className="sticky top-0 hidden h-dvh w-64 shrink-0 p-4 md:block"><div className="glass flex h-full flex-col p-4">
      <Link href="/" className="mb-8 px-2 pt-1" aria-label="QudraX home"><Logo /></Link>
      <div className="space-y-1">{nav.map(([h, l, I]) => { const on = p === h; return (
        <Link key={h} href={h} aria-current={on ? "page" : undefined} className={`relative flex items-center gap-3 rounded-lg px-3 py-2.5 transition-colors ${on ? "text-cyan" : "text-ink/70 hover:text-ink"}`}>
          {on && <motion.span layoutId="nav-active" className="absolute inset-0 rounded-lg bg-cyan/15" transition={{ type: "spring", stiffness: 400, damping: 34 }} />}
          <I size={18} className="relative" /><span className="relative">{l}</span>
          {done[h] && <Check size={14} className="relative ml-auto text-ok" aria-label="Done" />}</Link>); })}</div>
      <Link href={j.next.href} onClick={j.begin} className="btn-ghost mt-auto flex-col !items-start !gap-0.5 !p-3 text-left"><span className="text-xs text-ink/60">Next step</span><span className="text-sm font-medium">{j.next.cta}</span></Link>
    </div></nav>
    <main id="main" className="min-w-0 max-w-6xl flex-1 p-5 pb-28 md:p-10 md:pb-10">{children}</main>
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-navy/90 backdrop-blur md:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="grid grid-cols-5">{nav.map(([h, l, I]) => { const on = p === h; return (
        <Link key={h} href={h} aria-current={on ? "page" : undefined} className={`flex flex-col items-center gap-1 py-2.5 text-[11px] ${on ? "text-cyan" : "text-ink/60"}`}><I size={20} />{l === "The Mirror" ? "Mirror" : l}</Link>); })}</div></nav>
  </div>);
  return <MotionConfig reducedMotion="user">{body}{toaster}</MotionConfig>;
}
