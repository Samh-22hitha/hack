"use client";
import { useEffect, useRef } from "react";
// A few slow-drifting dots. Static when the user prefers reduced motion.
export default function Particles({ count = 46 }: { count?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!, ctx = cv.getContext("2d")!; const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dpr = Math.min(2, window.devicePixelRatio || 1); let w = 0, h = 0, raf = 0;
    const pts = Array.from({ length: count }, () => ({ x: Math.random(), y: Math.random(), r: 0.6 + Math.random() * 1.4, vx: (Math.random() - 0.5) * 0.00006,
      vy: -0.00004 - Math.random() * 0.00008, c: Math.random() < 0.7 ? "0,217,255" : "139,92,246", a: 0.25 + Math.random() * 0.5 }));
    const size = () => { w = cv.clientWidth; h = cv.clientHeight; cv.width = w * dpr; cv.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    const draw = (dt: number) => { ctx.clearRect(0, 0, w, h);
      for (const p of pts) { if (!reduce) { p.x += p.vx * dt; p.y += p.vy * dt; if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); } if (p.x < 0) p.x = 1; if (p.x > 1) p.x = 0; }
        ctx.beginPath(); ctx.fillStyle = `rgba(${p.c},${p.a})`; ctx.arc(p.x * w, p.y * h, p.r, 0, Math.PI * 2); ctx.fill(); } };
    let last = performance.now(); const loop = (now: number) => { draw(Math.min(50, now - last)); last = now; raf = requestAnimationFrame(loop); };
    size(); draw(0); if (!reduce) raf = requestAnimationFrame(loop);
    const ro = new ResizeObserver(() => { size(); draw(0); }); ro.observe(cv);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [count]);
  return <canvas ref={ref} aria-hidden className="pointer-events-none absolute inset-0 h-full w-full" />;
}
