"use client";
import { useEffect, useRef, type MutableRefObject } from "react";
// Bars scale with `level` (0 to 1). Driven by a ref so it animates at frame rate without re-rendering React.
export default function Waveform({ active, level, color, bars = 32 }: { active: boolean; level: MutableRefObject<number>; color: string; bars?: number }) {
  const els = useRef<(HTMLSpanElement | null)[]>([]);
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches; let raf = 0;
    const tick = (now: number) => { const t = now / 1000; const lvl = active ? level.current : 0;
      els.current.forEach((el, i) => { if (!el) return;
        const wob = 0.5 + 0.5 * Math.sin(t * 6 + i * 0.7) * Math.sin(t * 2.3 + i * 0.31);
        const h = !active ? 0.06 : reduce ? 0.15 + lvl * 0.5 : 0.08 + (0.12 + lvl * 0.88) * Math.max(0.15, wob);
        el.style.transform = `scaleY(${Math.min(1, h)})`; });
      raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [active, level]);
  return (<div aria-hidden className="flex h-12 items-center justify-center gap-[3px] transition-opacity" style={{ opacity: active ? 1 : 0.35 }}>
    {Array.from({ length: bars }, (_, i) => <span key={i} ref={(el) => { els.current[i] = el; }} className="block h-full w-[3px] origin-center rounded-full" style={{ background: color, transform: "scaleY(0.06)" }} />)}</div>);
}
