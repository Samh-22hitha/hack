import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
export type Scores = { relevance: number; clarity: number; structure: number; delivery: number };
export type Answer = { q: string; transcript: string; scores: Scores };
export type AvatarState = "idle" | "speaking" | "listening" | "thinking";
type Data = { role: string; skills: string[]; questions: string[]; round: 1 | 2; rounds: Record<number, Answer[]>; demo: boolean };
type S = Data & {
  setProfile: (role: string, skills: string[], questions: string[], demo?: boolean) => void;
  addAnswer: (a: Answer, demo?: boolean) => void; startRound: (r: 1 | 2) => void; reset: () => void };
const DEFAULT_QUESTIONS = ["Walk me through the architecture of your most recent project.", "How did you handle errors and edge cases in that project?", "What would you change if the project had ten times more users?"];
const fresh = (): Data => ({ role: "Java Backend Developer", skills: [], questions: DEFAULT_QUESTIONS, round: 1, rounds: { 1: [], 2: [] }, demo: false });
// Persisted so a refresh in the middle of a session (or after an interview) does not wipe the user's answers.
// skipHydration: Shell calls rehydrate() after mount, which keeps server and first client render identical.
export const useStore = create<S>()(persist((set) => ({
  ...fresh(),
  // A new resume means new questions, so earlier answers no longer match and start over.
  setProfile: (role, skills, questions, demo = false) => set({ role, skills, questions, round: 1, rounds: { 1: [], 2: [] }, demo }),
  addAnswer: (a, demo) => set((s) => ({ demo: s.demo || !!demo, rounds: { ...s.rounds, [s.round]: [...s.rounds[s.round], a] } })),
  startRound: (round) => set((s) => ({ round, rounds: { ...s.rounds, [round]: [] } })),
  reset: () => set(fresh()),
}), {
  name: "qudrax-session-v1", version: 1, skipHydration: true,
  storage: createJSONStorage(() => localStorage),
  partialize: (s) => ({ role: s.role, skills: s.skills, questions: s.questions, round: s.round, rounds: s.rounds, demo: s.demo }),
}));
export const avg = (a: Answer[], k: keyof Scores) => a.length ? Math.round(a.reduce((t, x) => t + x.scores[k], 0) / a.length) : 0;
