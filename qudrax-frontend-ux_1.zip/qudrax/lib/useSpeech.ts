"use client";
import { useRef, useCallback, useEffect } from "react";
export function useSpeech() {
  const rec = useRef<any>(null); const text = useRef(""); const base = useRef(""); const want = useRef(false); const tok = useRef(0); const started = useRef(0);
  // Each utterance gets a token, so the "ended" event of a cancelled question can never mark a newer question as finished.
  const cancel = useCallback(() => { tok.current++; if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel(); }, []);
  const speak = useCallback((t: string, onEnd: () => void) => {
    if (typeof speechSynthesis === "undefined") { onEnd(); return; }
    const id = ++tok.current; const done = () => { if (id === tok.current) onEnd(); };
    const u = new SpeechSynthesisUtterance(t); u.onend = done; u.onerror = done; speechSynthesis.cancel(); speechSynthesis.speak(u); }, []);
  const listen = useCallback((onText: (t: string) => void, onError?: (msg: string) => void) => {
    const R = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition; if (!R) return false;
    text.current = ""; base.current = ""; want.current = true;
    const make = () => { const r = new R(); r.continuous = true; r.interimResults = true; r.lang = "en-IN";
      r.onresult = (e: any) => { const s = Array.from(e.results).map((x: any) => x[0].transcript).join(" "); text.current = (base.current + " " + s).trim(); onText(text.current); };
      r.onerror = (e: any) => {
        if (e.error === "not-allowed" || e.error === "service-not-allowed") { want.current = false; onError?.("Microphone access is blocked. Allow it in your browser settings and try again."); }
        else if (e.error === "audio-capture") { want.current = false; onError?.("No microphone was found."); } };
      // Browsers end recognition after a pause even in continuous mode. Restart it and keep what was said so far.
      r.onend = () => { if (!want.current || rec.current !== r) return;
        if (Date.now() - started.current < 800) { want.current = false; onError?.("Speech recognition stopped. Check your connection and try again."); return; }
        base.current = text.current; try { const n = make(); started.current = Date.now(); n.start(); rec.current = n; } catch { want.current = false; } };
      return r; };
    const r = make(); rec.current = r; started.current = Date.now(); r.start(); return true; }, []);
  // Resolves once the browser has delivered the final words, so the end of an answer is not lost.
  const stop = useCallback(() => new Promise<string>((res) => { want.current = false; const r = rec.current; rec.current = null; if (!r) return res(text.current);
    const done = () => res(text.current); r.onend = done; r.onerror = () => {}; try { r.stop(); } catch { done(); } setTimeout(done, 700); }), []);
  useEffect(() => () => { want.current = false; rec.current?.abort?.(); if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel(); }, []);
  return { speak, listen, stop, cancel };
}
