"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link"; import dynamic from "next/dynamic"; import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion"; import { Mic, Square, PhoneOff, Volume2 } from "lucide-react"; import { toast } from "sonner";
import StatusPill from "@/components/StatusPill"; import Waveform from "@/components/Waveform";
import { useStore, type AvatarState } from "@/lib/store"; import { useSpeech } from "@/lib/useSpeech"; import { useMicLevel } from "@/lib/useMicLevel"; import { isDemo, scoreAnswer } from "@/lib/api";
const Avatar = dynamic(() => import("@/components/Avatar"), { ssr: false, loading: () => <div className="grid h-full place-items-center text-sm text-ink/50">Loading interviewer…</div> });
const COLOR: Record<AvatarState, string> = { idle: "#00D9FF", speaking: "#00D9FF", listening: "#10B981", thinking: "#8B5CF6" };
const HINT: Record<AvatarState, string> = { idle: "Press Answer when you are ready. Your words appear here as you speak.", speaking: "Listen to the question first.", listening: "Say your answer, then press Finish answer.", thinking: "Scoring your answer…" };

function Room() {
  const { questions, round, addAnswer } = useStore(); const answered = useStore((s) => s.rounds[s.round].length); const r = useRouter(); const { speak, listen, stop, cancel } = useSpeech();
  const level = useRef(0); const mic = useMicLevel(level);
  const [i, setI] = useState(0); const [state, setState] = useState<AvatarState>("idle"); const [live, setLive] = useState(""); const [secs, setSecs] = useState(0); const [confirmEnd, setConfirmEnd] = useState(false);
  const n = questions.length, color = COLOR[state];
  useEffect(() => { const t = setInterval(() => setSecs((s) => s + 1), 1000); return () => clearInterval(t); }, []);
  useEffect(() => () => mic.stop(), []); // eslint-disable-line -- release the microphone if the user leaves mid-answer
  const ask = useCallback((q: string) => { setState("speaking"); level.current = 0.6; speak(q, () => { level.current = 0; setState("idle"); }); }, [speak]);
  useEffect(() => { setLive(""); ask(questions[i]); return () => cancel(); }, [i]); // eslint-disable-line
  useEffect(() => { if (!confirmEnd) return; const t = setTimeout(() => setConfirmEnd(false), 4000); return () => clearTimeout(t); }, [confirmEnd]);

  const begin = () => {
    const ok = listen(setLive, (m) => { toast.error(m); mic.stop(); setState("idle"); });
    if (!ok) { toast.error("Speech recognition is not supported in this browser. Use Chrome or Edge."); return; }
    setState("listening"); mic.start(); };
  const finish = async () => {
    setState("thinking"); mic.stop(); const t = ((await stop()) || live).trim();
    if (!t) { toast("We didn’t catch anything. Check your microphone and try again."); setLive(""); setState("idle"); return; }
    const scores = await scoreAnswer(questions[i], t, round); addAnswer({ q: questions[i], transcript: t, scores }, isDemo());
    if (i + 1 < n) setI(i + 1); else r.push("/report"); };
  const end = () => { if (!confirmEnd) { setConfirmEnd(true); return; } cancel(); mic.stop(); r.push(answered ? "/report" : "/dashboard"); };

  const C = 2 * Math.PI * 17;
  return (<div className="relative grid h-dvh grid-rows-[auto_1fr_auto] overflow-hidden">
    <div aria-hidden className="pointer-events-none absolute -top-32 left-1/2 size-[620px] -translate-x-1/2 rounded-full blur-[130px] transition-colors duration-700" style={{ background: color + "33" }} />
    <header className="relative z-10 flex items-center justify-between gap-4 px-4 py-3 sm:px-6">
      <div className="flex items-center gap-3">
        <div className="relative size-11" role="img" aria-label={`${i} of ${n} questions answered`}><svg viewBox="0 0 40 40" className="-rotate-90"><circle cx="20" cy="20" r="17" fill="none" stroke="#ffffff1a" strokeWidth="3" />
          <circle cx="20" cy="20" r="17" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - i / n)} style={{ transition: "stroke-dashoffset .6s ease, stroke .4s" }} /></svg>
          <span className="absolute inset-0 grid place-items-center font-num text-xs font-medium">{i + 1}/{n}</span></div>
        <div className="text-sm leading-tight"><p className="font-medium">Question {i + 1} of {n}</p><p className="text-ink/60">Attempt {round}</p></div></div>
      <span className="font-num text-sm tabular-nums text-ink/70" aria-label="Time elapsed">{Math.floor(secs / 60)}:{String(secs % 60).padStart(2, "0")}</span></header>
    <div className="relative min-h-0"><Avatar state={state} />
      <div className="absolute inset-x-0 top-2 flex justify-center"><StatusPill state={state} /></div>
      <div className="absolute inset-x-0 bottom-2 flex min-h-14 justify-center px-4">
        <AnimatePresence mode="wait"><motion.p key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }} className="max-w-xl text-balance text-center font-display text-lg sm:text-xl">{questions[i]}</motion.p></AnimatePresence></div></div>
    <footer className="relative z-10 flex flex-col items-center gap-3 p-4 pb-6">
      <Waveform active={state === "listening" || state === "speaking"} level={level} color={color} />
      <p aria-live="polite" className="surface min-h-11 w-full max-w-2xl px-4 py-2.5 text-sm text-ink/80">{live || <span className="text-ink/50">{HINT[state]}</span>}</p>
      <div className="flex flex-wrap justify-center gap-3">
        <span className="relative">{state === "listening" && <span aria-hidden className="absolute inset-0 animate-ping rounded-xl bg-ok/50" />}
          <button onClick={() => state === "listening" ? finish() : state === "idle" ? begin() : undefined} disabled={state === "speaking" || state === "thinking"} className={`btn relative disabled:opacity-40 ${state === "listening" ? "btn-live" : ""}`}>
            {state === "listening" ? <><Square size={18} />Finish answer</> : state === "thinking" ? "Scoring…" : <><Mic size={18} />Answer</>}</button></span>
        <button onClick={() => ask(questions[i])} disabled={state !== "idle"} className="btn-ghost"><Volume2 size={18} />Repeat question</button>
        <button onClick={end} className={`btn-ghost ${confirmEnd ? "!border-rose-300/60 !text-rose-200" : ""}`}><PhoneOff size={18} />{confirmEnd ? "Confirm end" : "End interview"}</button>
      </div></footer></div>);
}

function Complete({ onRetry }: { onRetry: () => void }) {
  const { round, startRound } = useStore();
  return (<div className="grid min-h-dvh place-items-center p-6"><div className="surface max-w-md space-y-4 p-8 text-center">
    <h1 className="text-2xl font-semibold">Attempt {round} is complete</h1>
    <p className="text-ink/70">{round === 1 ? "Retry the same questions to see how much you improve." : "Both attempts are recorded. Compare them side by side."}</p>
    <div className="flex flex-wrap justify-center gap-3"><Link href="/report" className="btn">View report</Link>
      {round === 1 ? <button className="btn-ghost" onClick={() => { startRound(2); onRetry(); }}>Retry the same questions</button> : <Link href="/mirror" className="btn-ghost">See your progress</Link>}</div>
    <Link href="/dashboard" className="inline-block text-sm text-ink/60 underline underline-offset-4">Back to dashboard</Link></div></div>);
}

// Opening the room for an attempt that is already finished shows a summary instead of silently adding answers on top.
export default function Page() {
  const [done, setDone] = useState(() => { const s = useStore.getState(); return s.rounds[s.round].length >= s.questions.length; });
  return done ? <Complete onRetry={() => setDone(false)} /> : <Room />;
}
