"use client";
import { useEffect, useRef, useState, type DragEvent } from "react"; import { useRouter } from "next/navigation";
import { UploadCloud, FileText, X, Check, Loader2 } from "lucide-react"; import { toast } from "sonner";
import { analyzeResume, isDemo } from "@/lib/api"; import { useStore } from "@/lib/store"; import SkillGalaxy from "@/components/SkillGalaxy";
const MAX = 10 * 1024 * 1024;
const ROLES = ["Java Backend Developer", "Frontend Developer", "Full-Stack Developer", "Data Analyst", "DevOps Engineer", "Machine Learning Engineer"];
const STEPS = ["Reading your resume", "Finding your skills", "Writing your questions"];
const size = (n: number) => n >= 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
export default function Resume() {
  const { skills, questions, role: saved, demo, setProfile } = useStore(); const r = useRouter(); const result = useRef<HTMLDivElement>(null);
  const [file, setFile] = useState<File | null>(null); const [role, setRole] = useState(saved); const [busy, setBusy] = useState(false); const [step, setStep] = useState(0);
  const [error, setError] = useState(""); const [drag, setDrag] = useState(false);
  useEffect(() => { if (!busy) return; setStep(0); const t = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 1400); return () => clearInterval(t); }, [busy]);
  const pick = (f?: File | null) => { if (!f) return;
    if (!(f.type === "application/pdf" || /\.pdf$/i.test(f.name))) return setError("That file is not a PDF. Export your resume as a PDF and try again.");
    if (f.size > MAX) return setError("That PDF is larger than 10 MB. Try a smaller export.");
    setError(""); setFile(f); };
  const drop = (e: DragEvent) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files?.[0]); };
  const go = async () => { if (!file || busy) return; setBusy(true);
    try { const d = await analyzeResume(file, role.trim() || "Software Engineer"); const off = isDemo(); setProfile(role.trim() || "Software Engineer", d.skills, d.questions, off);
      toast.success(`Found ${d.skills.length} skills and wrote ${d.questions.length} questions`);
      if (off) toast.warning("The analysis server could not be reached, so sample skills are shown.");
      setTimeout(() => result.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    } finally { setBusy(false); } };
  return (<div className="grid gap-6 md:grid-cols-2">
    <div className="surface space-y-5 p-6"><h1 className="text-3xl font-semibold">Upload your resume</h1>
      {file ? (<div className="flex items-center gap-3 rounded-xl border border-ok/40 bg-ok/10 p-4">
        <span className="check grid size-9 shrink-0 place-items-center rounded-full bg-ok text-navy"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M5 12.5l4.5 4.5L19 7.5" /></svg></span>
        <div className="min-w-0 flex-1"><p className="truncate font-medium">{file.name}</p><p className="text-sm text-ink/60">{size(file.size)}, ready to analyse</p></div>
        <button type="button" onClick={() => setFile(null)} disabled={busy} aria-label="Remove file" className="rounded-lg p-2 text-ink/60 hover:bg-white/10 hover:text-ink disabled:opacity-40"><X size={18} /></button></div>) : (
        <label onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={drop}
          className={`flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed p-10 text-center transition focus-within:outline focus-within:outline-2 focus-within:outline-cyan ${drag ? "border-cyan bg-cyan/10" : "border-cyan/40 hover:bg-cyan/5"}`}>
          <UploadCloud className="text-cyan" size={36} /><span className="font-medium">Drop a PDF here or click to browse</span><span className="text-sm text-ink/55">PDF only, up to 10 MB</span>
          <input type="file" accept="application/pdf,.pdf" className="sr-only" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} /></label>)}
      {error && <p role="alert" className="text-sm text-rose-300">{error}</p>}
      <label className="block text-sm text-ink/70">Target role<input list="roles" value={role} onChange={(e) => setRole(e.target.value)} className="mt-1 w-full rounded-lg border border-white/10 bg-deep p-3 text-ink" /></label>
      <datalist id="roles">{ROLES.map((x) => <option key={x} value={x} />)}</datalist>
      {busy ? (<div role="status" className="space-y-3"><div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="indeterminate h-full w-2/5 rounded-full bg-gradient-to-r from-cyan to-violet" /></div>
        <ul className="space-y-1.5 text-sm">{STEPS.map((s, i) => (<li key={s} className={`flex items-center gap-2 ${i <= step ? "text-ink" : "text-ink/40"}`}>
          {i < step ? <Check size={15} className="text-ok" /> : i === step ? <Loader2 size={15} className="animate-spin text-cyan" /> : <span className="size-[15px]" />}{s}</li>))}</ul></div>)
        : <button className="btn disabled:opacity-40" disabled={!file} onClick={go}><FileText size={18} />Analyse resume</button>}
    </div>
    <div ref={result} className="surface scroll-mt-6 p-6"><h2 className="mb-4 text-xl font-semibold">Skill galaxy</h2>
      <SkillGalaxy skills={skills} idle="The skills found in your resume appear here." />
      {skills.length > 0 && <div className="mt-5 space-y-3 border-t border-white/10 pt-5">
        {demo && <p role="note" className="rounded-lg bg-amber-300/10 px-3 py-2 text-sm text-amber-100">Sample data: the analysis server could not be reached.</p>}
        <p className="font-medium text-ok">{questions.length} personalised questions are ready.</p><button className="btn" onClick={() => r.push("/interview")}>Enter interview room</button></div>}</div>
  </div>);
}
