import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk, Outfit } from "next/font/google";
import Shell from "@/components/Shell";
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const space = Space_Grotesk({ subsets: ["latin"], variable: "--font-space", display: "swap" });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-num", display: "swap" });
export const metadata: Metadata = {
  title: "QudraX · AI Interview Mirror",
  description: "Practise interviews out loud with an AI interviewer, then retry the same questions and see exactly what improved.",
};
export const viewport: Viewport = { themeColor: "#080B18", width: "device-width", initialScale: 1 };
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className={`${inter.variable} ${space.variable} ${outfit.variable} font-sans antialiased`}><Shell>{children}</Shell></body></html>);
}
