"use client";
import { motion } from "framer-motion";
// A short fade between pages. Re-mounts on every navigation, which is what triggers it.
export default function Template({ children }: { children: React.ReactNode }) {
  return <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25, ease: "easeOut" }}>{children}</motion.div>;
}
