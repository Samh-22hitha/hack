"use client";
import Link from "next/link"; import { Check, Circle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Legend, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { useStore, avg } from "@/lib/store"; import { useJourney } from "@/lib/journey"; import { KEYS, LABEL, overall } from "@/lib/score"; import { useCountUp } from "@/lib/useCountUp"; import ScoreRing from "@/components/ScoreRing";
const sign = (n: number) => (n > 0 ? "+" : "") + n;
function Gain({ pct }: { pct: number }) { const n = useCountUp(Math.abs(pct)); return <span className="font-num">{pct < 0 ? "-" : "+"}{n}%</span>; }
export default function Mirror() {
  const { rounds, demo } = useStore(); const j = useJourney(); const [a, b] = [rounds[1], rounds[2]];
  if (!a.length || !b.length) return (<div className="surface max-w-lg space-y-5 p-8"><h1 className="text-2xl font-semibold">The Mirror needs two attempts</h1>
    <p className="text-ink/70">Answer the same questions twice and we will show what changed.</p>
    <ul className="space-y-2">{([["Attempt 1", a.length > 0], ["Attempt 2", b.length > 0]] as const).map(([l, ok]) => <li key={l} className={`flex items-center gap-2 ${ok ? "" : "text-ink/50"}`}>{ok ? <Check size={16} className="text-ok" /> : <Circle size={16} />}{l}</li>)}</ul>
    <Link href={j.next.href} onClick={j.begin} className="btn">{j.next.cta}</Link></div>);
  const s1 = overall(a), s2 = overall(b); const gain = s1 ? Math.round(((s2 - s1) / s1) * 100) : 0;
  const rows = KEYS.map((k) => ({ k, name: LABEL[k], x: avg(a, k), y: avg(b, k), d: avg(b, k) - avg(a, k) })); const best = [...rows].sort((p, q) => q.d - p.d)[0], worst = [...rows].sort((p, q) => p.d - q.d)[0];
  const data = rows.map((r) => ({ k: r.name, "Attempt 1": r.x, "Attempt 2": r.y }));
  return (<div className="space-y-6"><h1 className="text-4xl font-semibold">Your progress, reflected back</h1>
    {demo && <p role="note" className="rounded-xl border border-amber-300/30 bg-amber-300/10 px-4 py-3 text-sm text-amber-100">The scoring server could not be reached, so these scores are demo estimates.</p>}
    <div className="glass flex flex-wrap items-center justify-center gap-6 p-6 sm:gap-10">
      <ScoreRing value={s1} size={132} label="Attempt 1" from="#8B5CF6" to="#8B5CF6" />
      <div className="text-center"><p className={`text-5xl font-semibold ${gain >= 0 ? "text-ok" : "text-amber-300"}`}><Gain pct={gain} /></p><p className="mt-1 text-sm text-ink/60">{gain >= 0 ? "overall improvement" : "overall change"}</p></div>
      <ScoreRing value={s2} size={132} label="Attempt 2" from="#00D9FF" to="#10B981" /></div>
    <p className="text-ink/80">{best.d > 0 ? `Biggest jump: ${best.name} (${sign(best.d)}). ` : ""}{worst.d < 0 ? `Watch ${worst.name}, which dipped by ${Math.abs(worst.d)}.` : worst.d === 0 && best.d <= 0 ? "Scores stayed level between attempts." : ""}</p>
    <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
      <div className="surface divide-y divide-white/10 p-2">{rows.map((r) => (<div key={r.k} className="flex items-center justify-between gap-3 px-3 py-3.5"><span>{r.name}</span>
        <span className="flex items-center gap-3"><span className="font-num text-sm text-ink/60">{r.x} to {r.y}</span><span className={`font-num w-12 rounded-full py-0.5 text-center text-sm font-medium ${r.d > 0 ? "bg-ok/15 text-ok" : r.d < 0 ? "bg-amber-300/15 text-amber-300" : "bg-white/10 text-ink/70"}`}>{sign(r.d)}</span></span></div>))}</div>
      <div className="surface h-72 p-4"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid stroke="#ffffff10" vertical={false} /><XAxis dataKey="k" stroke="#94a3b8" /><YAxis domain={[0, 100]} stroke="#94a3b8" /><Tooltip cursor={{ fill: "#ffffff0a" }} contentStyle={{ background: "#10182B", border: "1px solid #ffffff1f", borderRadius: 8 }} /><Legend />
        <Bar dataKey="Attempt 1" fill="#8B5CF6" radius={6} /><Bar dataKey="Attempt 2" fill="#00D9FF" radius={6} /></BarChart></ResponsiveContainer></div></div>
    <section aria-labelledby="tl"><h2 id="tl" className="mb-3 font-semibold">Timeline</h2>
      <ol className="surface space-y-5 p-5">{[[1, a, s1], [2, b, s2]].map(([n, r, s]) => (<li key={n as number} className="flex items-center gap-4"><span className={`grid size-9 place-items-center rounded-full font-num text-sm font-semibold text-navy ${n === 1 ? "bg-violet" : "bg-cyan"}`}>{n as number}</span>
        <div><p className="font-medium">Attempt {n as number}</p><p className="text-sm text-ink/60">{(r as typeof a).length} answers, overall {s as number}</p></div></li>))}</ol></section>
    <div className="grid gap-4 md:grid-cols-2">{[a, b].map((r, n) => (<details key={n} className="surface p-5"><summary className="cursor-pointer font-semibold">Attempt {n + 1} transcript</summary>
      <div className="mt-3 space-y-3">{r.map((x, i) => <div key={i}><p className="text-sm text-cyan">{x.q}</p><p className="text-sm text-ink/70">{x.transcript}</p></div>)}</div></details>))}</div>
    <Link href="/dashboard" className="btn-ghost inline-flex">Back to dashboard</Link>
  </div>);
}
