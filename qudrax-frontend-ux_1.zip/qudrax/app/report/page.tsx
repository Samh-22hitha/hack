"use client";
import Link from "next/link"; import { motion, useReducedMotion } from "framer-motion";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import { useStore, avg } from "@/lib/store"; import { useJourney } from "@/lib/journey"; import { KEYS, LABEL, TIPS, answerScore, overall, tier } from "@/lib/score"; import { useCountUp } from "@/lib/useCountUp"; import ScoreRing from "@/components/ScoreRing";
function Bar({ name, v }: { name: string; v: number }) {
  const reduce = useReducedMotion(); const n = useCountUp(v); const t = tier(v);
  return (<div><div className="mb-1.5 flex justify-between text-sm"><span>{name}</span><span className="font-num font-medium">{n}</span></div>
    <div className="h-2 overflow-hidden rounded-full bg-white/10"><motion.div className={`h-full rounded-full ${t.bg}`} initial={{ width: reduce ? `${v}%` : 0 }} animate={{ width: `${v}%` }} transition={{ duration: reduce ? 0 : 0.9, ease: "easeOut" }} /></div></div>);
}
export default function Report() {
  const { rounds, round, startRound, demo } = useStore(); const j = useJourney(); const a = rounds[round];
  if (!a.length) return (<div className="surface max-w-lg space-y-4 p-8"><h1 className="text-2xl font-semibold">No report yet</h1><p className="text-ink/70">Your report appears here as soon as you answer a question in the interview room.</p>
    <Link href={j.next.href} onClick={j.begin} className="btn">{j.next.cta}</Link></div>);
  const data = KEYS.map((k) => ({ k, name: LABEL[k], v: avg(a, k) })); const score = overall(a); const t = tier(score); const focus = [...data].sort((x, y) => x.v - y.v).slice(0, 2);
  return (<div className="space-y-6">
    <div className="flex flex-wrap items-end justify-between gap-3"><h1 className="text-4xl font-semibold">Interview report</h1><span className="rounded-full border border-white/15 px-3 py-1 text-sm text-ink/70">Attempt {round}</span></div>
    {demo && <p role="note" className="rounded-xl border border-amber-300/30 bg-amber-300/10 px-4 py-3 text-sm text-amber-100">The scoring server could not be reached, so these scores are demo estimates based on answer length.</p>}
    <div className="grid gap-6 md:grid-cols-2">
      <div className="glass flex items-center gap-6 p-6"><ScoreRing value={score} size={144} label="overall" />
        <div><p className={`text-2xl font-semibold ${t.text}`}>{t.label}</p><p className="mt-1 text-sm text-ink/60">Average of relevance, clarity, structure and delivery across {a.length} {a.length === 1 ? "answer" : "answers"}.</p></div></div>
      <div className="surface h-64 p-4"><ResponsiveContainer width="100%" height="100%"><RadarChart data={data}><PolarGrid stroke="#ffffff22" /><PolarAngleAxis dataKey="name" stroke="#94a3b8" /><Radar dataKey="v" stroke="#00D9FF" fill="#00D9FF" fillOpacity={0.3} /></RadarChart></ResponsiveContainer></div></div>
    <div className="surface space-y-4 p-6"><h2 className="font-semibold">Skills</h2><div className="grid gap-x-8 gap-y-4 sm:grid-cols-2">{data.map((d) => <Bar key={d.k} name={d.name} v={d.v} />)}</div></div>
    <section aria-labelledby="focus"><h2 id="focus" className="mb-3 font-semibold">Where to focus next</h2>
      <div className="grid gap-4 sm:grid-cols-2">{focus.map((f) => { const k = KEYS.find((x) => LABEL[x] === f.name)!; return (<div key={k} className="surface p-5"><p className="text-sm text-ink/60">{f.name}, {f.v}/100</p><p className="mt-1 font-medium">{TIPS[k].title}</p><p className="mt-1 text-sm text-ink/70">{TIPS[k].tip}</p></div>); })}</div></section>
    <section aria-labelledby="answers" className="space-y-3"><h2 id="answers" className="font-semibold">Your answers</h2>
      {a.map((x, i) => { const s = answerScore(x), ts = tier(s); return (<div key={i} className="surface space-y-3 p-5">
        <div className="flex items-start justify-between gap-4"><p className="font-medium text-cyan">{x.q}</p><span className={`font-num shrink-0 text-xl font-semibold ${ts.text}`}>{s}</span></div>
        <p className="text-sm text-ink/70">{x.transcript}</p>
        <div className="flex flex-wrap gap-2">{KEYS.map((k) => <span key={k} className="rounded-full bg-white/[0.06] px-2.5 py-1 text-xs text-ink/70">{LABEL[k]} <b className="font-num text-ink">{x.scores[k]}</b></span>)}</div></div>); })}</section>
    <div className="flex flex-wrap gap-3">{round === 1 ? <Link href="/interview" onClick={() => startRound(2)} className="btn">Retry the same questions</Link> : <Link href="/mirror" className="btn">See your progress</Link>}
      <Link href="/dashboard" className="btn-ghost">Back to dashboard</Link></div>
  </div>);
}
