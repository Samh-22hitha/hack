"use client";
import Link from "next/link"; import dynamic from "next/dynamic"; import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion"; import { Play, FileUp, Mic, BarChart3, GitCompare } from "lucide-react";
import Logo from "@/components/Logo"; import Particles from "@/components/Particles"; import StatusPill from "@/components/StatusPill"; import type { AvatarState } from "@/lib/store";
const Avatar = dynamic(() => import("@/components/Avatar"), { ssr: false, loading: () => <div className="grid h-full place-items-center text-sm text-ink/50">Loading interviewer…</div> });
// The hero is a live demo: the interviewer asks, listens, then scores, in a loop.
const phases: { s: AvatarState; ms: number }[] = [{ s: "speaking", ms: 4800 }, { s: "listening", ms: 3600 }, { s: "thinking", ms: 2400 }];
const demoQs = ["Walk me through the architecture of your most recent project.", "How did you handle errors and edge cases in that project?", "What would you change if the project had ten times more users?"];
const steps = [
  { I: FileUp, t: "Upload your resume", d: "We find your skills and write questions about your own projects." },
  { I: Mic, t: "Answer out loud", d: "Speak to the interviewer. Your words are transcribed as you talk." },
  { I: BarChart3, t: "Get scored", d: "See relevance, clarity, structure and delivery for every answer." },
  { I: GitCompare, t: "Retry and compare", d: "Answer the same questions again and see exactly what improved." }];
export default function Landing() {
  const [step, setStep] = useState(0); const phase = step % 3; const state = phases[phase].s; const q = demoQs[Math.floor(step / 3) % demoQs.length];
  useEffect(() => { const t = setTimeout(() => setStep((s) => s + 1), phases[phase].ms); return () => clearTimeout(t); }, [step, phase]);
  return (<div className="relative min-h-dvh overflow-hidden">
    <Particles />
    <div aria-hidden className="pointer-events-none absolute -top-40 right-[-10%] size-[640px] rounded-full bg-violet/25 blur-[120px]" />
    <div aria-hidden className="pointer-events-none absolute bottom-[-20%] left-[-10%] size-[520px] rounded-full bg-cyan/15 blur-[120px]" />
    <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
      <Logo /><nav className="flex items-center gap-2"><Link href="/dashboard" className="btn-ghost">Dashboard</Link><Link href="/resume" className="btn"><Play size={16} />Start practising</Link></nav></header>
    <main className="relative z-10 mx-auto max-w-6xl px-6 pb-20">
      <section className="grid items-center gap-10 pt-6 lg:grid-cols-[1.05fr_1fr] lg:pt-14">
        <div>
          <h1 className="text-gradient text-5xl font-semibold leading-[1.05] sm:text-6xl">Interview yourself twice. See exactly what changed.</h1>
          <p className="mt-6 max-w-lg text-lg text-ink/70">Upload your resume, answer questions about your own projects out loud, then retry the same questions. QudraX scores every answer so you can watch yourself improve.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link href="/resume" className="btn !px-6 !py-3.5"><Play size={18} />Start practising</Link><Link href="/dashboard" className="btn-ghost !px-6 !py-3.5">Open dashboard</Link></div>
          <p className="mt-4 text-sm text-ink/50">Works best in Chrome or Edge, with a microphone.</p>
        </div>
        <div className="glass relative mx-auto aspect-[4/5] w-full max-w-[520px] overflow-hidden shadow-[0_0_90px_-25px_#00D9FF66] sm:aspect-square">
          <Avatar state={state} />
          <div className="absolute inset-x-0 top-3 flex justify-center"><StatusPill state={state} live={false} /></div>
          <div className="absolute inset-x-0 bottom-4 flex min-h-16 justify-center px-6">
            <AnimatePresence mode="wait"><motion.p key={`${step}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }} className="max-w-sm text-balance text-center font-display text-base text-ink sm:text-lg">
              {state === "thinking" ? "Scoring relevance, clarity, structure and delivery." : q}</motion.p></AnimatePresence></div>
        </div>
      </section>
      <section aria-labelledby="how" className="mt-24"><h2 id="how" className="mb-6 text-2xl font-semibold">How it works</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{steps.map(({ I, t, d }) => (<div key={t} className="glass p-5"><span className="grid size-10 place-items-center rounded-xl bg-cyan/15 text-cyan"><I size={20} /></span><h3 className="mt-4 font-semibold">{t}</h3><p className="mt-1.5 text-sm text-ink/65">{d}</p></div>))}</div></section>
    </main></div>);
}
