"use client";
import Link from "next/link"; import { Area, AreaChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Play, Check, Circle } from "lucide-react";
import { useStore, avg } from "@/lib/store"; import { useJourney } from "@/lib/journey"; import { KEYS, TIPS, answerScore, overall } from "@/lib/score"; import { useCountUp } from "@/lib/useCountUp"; import ScoreRing from "@/components/ScoreRing";
const sampleTrend = [{ d: "Mon", s: 61 }, { d: "Tue", s: 66 }, { d: "Wed", s: 70 }, { d: "Thu", s: 74 }, { d: "Fri", s: 78 }];
const tip = { contentStyle: { background: "#10182B", border: "1px solid #ffffff1f", borderRadius: 8 } };
function Stat({ label, value, prefix = "", suffix = "", note }: { label: string; value: number | null; prefix?: string; suffix?: string; note?: string }) {
  const n = useCountUp(value ?? 0);
  return (<div className="glass p-5"><p className="text-sm text-ink/60">{label}</p><p className="mt-2 font-num text-4xl font-semibold">{value === null ? "–" : `${prefix}${n}${suffix}`}</p>{note && <p className="mt-1 text-xs text-ink/50">{note}</p>}</div>);
}
const SampleTag = () => <span className="rounded-full border border-white/15 px-2 py-0.5 text-xs text-ink/60">Sample data</span>;
export default function Dashboard() {
  const { role, skills, rounds, questions, demo } = useStore(); const j = useJourney(); const live = j.a1;
  const latest = j.a2 ? rounds[2] : rounds[1]; const s1 = live ? overall(rounds[1]) : 0, s2 = j.a2 ? overall(rounds[2]) : 0;
  const gain = j.a2 && s1 ? Math.round(((s2 - s1) / s1) * 100) : null;
  const readiness = (j.analysed ? 40 : 0) + (j.a1 ? 30 : 0) + (j.a2 ? 30 : 0);
  const stats = live ? { n: (j.a1 ? 1 : 0) + (j.a2 ? 1 : 0), score: overall(latest), gain, answers: rounds[1].length + rounds[2].length } : { n: 5, score: 78, gain: 15 as number | null, answers: 24 };
  const weakest = live ? [...KEYS].sort((a, b) => avg(latest, a) - avg(latest, b))[0] : null;
  const topics = [weakest ? TIPS[weakest] : { title: "Lead with the answer", tip: "Open with a one-sentence answer before you explain." },
    ...(skills.length ? skills.slice(0, 2).map((s) => ({ title: `Explain ${s} in your own project`, tip: "Say what you chose it for, what went wrong, and what you would do differently." }))
      : [{ title: "Walk through a project you built", tip: "Cover the goal, your part, and the result in under two minutes." }, { title: "Describe a bug you tracked down", tip: "Explain how you found it, not just how you fixed it." }])].slice(0, 3);
  const perQuestion = questions.map((_, i) => ({ q: `Q${i + 1}`, "Attempt 1": rounds[1][i] ? answerScore(rounds[1][i]) : undefined, "Attempt 2": rounds[2][i] ? answerScore(rounds[2][i]) : undefined }));
  const checks = [[j.analysed, "Resume analysed"], [j.a1, "Attempt 1 recorded"], [j.a2, "Attempt 2 recorded"]] as const;
  return (<div className="space-y-8">
    <div className="flex flex-wrap items-end justify-between gap-4"><div><h1 className="text-4xl font-semibold">Welcome back</h1><p className="mt-1 text-ink/60">Next up: {role} interview</p></div>
      <Link href={j.next.href} onClick={j.begin} className="btn"><Play size={18} />{j.next.cta}</Link></div>
    {demo && <p role="note" className="rounded-xl border border-amber-300/30 bg-amber-300/10 px-4 py-3 text-sm text-amber-100">The analysis server could not be reached, so some results are demo estimates.</p>}
    <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
      <div className="surface flex flex-col justify-between gap-6 p-6"><div><h2 className="text-xl font-semibold">{j.next.title}</h2><p className="mt-1.5 max-w-md text-ink/65">{j.next.body}</p></div>
        <div><Link href={j.next.href} onClick={j.begin} className="btn">{j.next.cta}</Link></div></div>
      <div className="surface flex items-center gap-5 p-6"><ScoreRing value={readiness} size={112} label="ready" />
        <div><h2 className="font-semibold">Interview readiness</h2><ul className="mt-2 space-y-1.5 text-sm">{checks.map(([ok, l]) => (<li key={l} className={`flex items-center gap-2 ${ok ? "text-ink" : "text-ink/50"}`}>{ok ? <Check size={15} className="text-ok" /> : <Circle size={15} />}{l}</li>))}</ul></div></div>
    </div>
    <section aria-label="Statistics"><div className="mb-3 flex items-center gap-3 empty:hidden">{!live && <SampleTag />}</div>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label={live ? "Attempts completed" : "Interviews"} value={stats.n} /><Stat label={live ? "Latest score" : "Average score"} value={stats.score} suffix="/100" />
        <Stat label="Improvement" value={stats.gain} prefix={stats.gain !== null && stats.gain >= 0 ? "+" : ""} suffix="%" note={live && stats.gain === null ? "Finish attempt 2 to see this" : undefined} />
        <Stat label={live ? "Answers recorded" : "Answers practised"} value={stats.answers} /></div></section>
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      <div className="surface h-80 p-5"><div className="mb-3 flex items-center justify-between"><h2 className="font-medium">{live ? "Score by question" : "Score trend"}</h2>{!live && <SampleTag />}</div>
        <ResponsiveContainer width="100%" height="85%">{live ? (
          <LineChart data={perQuestion}><CartesianGrid stroke="#ffffff10" vertical={false} /><XAxis dataKey="q" stroke="#94a3b8" /><YAxis domain={[0, 100]} stroke="#94a3b8" /><Tooltip {...tip} /><Legend />
            <Line dataKey="Attempt 1" stroke="#8B5CF6" strokeWidth={3} dot={{ r: 4 }} connectNulls /><Line dataKey="Attempt 2" stroke="#00D9FF" strokeWidth={3} dot={{ r: 4 }} connectNulls /></LineChart>) : (
          <AreaChart data={sampleTrend}><defs><linearGradient id="trend" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#00D9FF" stopOpacity={0.4} /><stop offset="1" stopColor="#00D9FF" stopOpacity={0} /></linearGradient></defs>
            <CartesianGrid stroke="#ffffff10" vertical={false} /><XAxis dataKey="d" stroke="#94a3b8" /><YAxis domain={[40, 100]} stroke="#94a3b8" /><Tooltip {...tip} /><Area dataKey="s" stroke="#00D9FF" strokeWidth={3} fill="url(#trend)" /></AreaChart>)}</ResponsiveContainer></div>
      <div className="surface p-5"><h2 className="mb-3 font-medium">Recommended practice</h2><ul className="space-y-3">{topics.map((t) => (<li key={t.title} className="rounded-xl bg-white/[0.04] p-3.5"><p className="font-medium">{t.title}</p><p className="mt-1 text-sm text-ink/60">{t.tip}</p></li>))}</ul></div>
    </div>
    <section aria-labelledby="recent"><h2 id="recent" className="mb-3 font-medium">Recent interviews</h2>
      {!live ? <p className="surface p-5 text-ink/60">Your attempts will appear here after your first interview.</p> : (
        <div className="grid gap-4 sm:grid-cols-2">{([1, 2] as const).filter((n) => rounds[n].length).map((n) => (<div key={n} className="surface flex items-center gap-5 p-5">
          <ScoreRing value={overall(rounds[n])} size={84} stroke={8} from={n === 1 ? "#8B5CF6" : "#00D9FF"} to={n === 1 ? "#8B5CF6" : "#10B981"} />
          <div><p className="font-semibold">Attempt {n}</p><p className="text-sm text-ink/60">{rounds[n].length} of {questions.length} answers</p>
            {n === (j.a2 ? 2 : 1) && <Link href="/report" className="mt-2 inline-block text-sm text-cyan underline underline-offset-4">Open report</Link>}</div></div>))}</div>)}</section>
  </div>);
}
